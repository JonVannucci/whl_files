from ._Keithley_2600 import Keithley2600


class Keithley2635B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2635B Source-Meter
    """

    pass
