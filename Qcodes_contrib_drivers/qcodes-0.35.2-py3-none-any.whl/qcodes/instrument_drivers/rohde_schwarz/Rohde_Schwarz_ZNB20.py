from .ZNB import ZNB


class RohdeSchwarzZNB20(ZNB):
    """
    QCoDeS driver for Rohde & Schwarz ZNB20

    """

    pass
