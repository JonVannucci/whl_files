# Ensuring backwards compatibility

from .RTO1000 import RTO1000 as RTE1000
