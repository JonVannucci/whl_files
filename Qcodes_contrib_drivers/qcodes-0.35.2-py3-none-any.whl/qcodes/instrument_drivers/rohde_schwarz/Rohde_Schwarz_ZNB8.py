# Ensuring backwards compatibility

from .ZNB import ZNB


class RohdeSchwarzZNB8(ZNB):
    """
    QCoDeS driver for Rohde & Schwarz ZNB8

    """

    pass
