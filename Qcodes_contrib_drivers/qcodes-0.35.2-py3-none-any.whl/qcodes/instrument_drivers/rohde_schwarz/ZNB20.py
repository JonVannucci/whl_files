# Ensuring backwards compatibility

from .ZNB import ZNB

ZNB20 = ZNB
