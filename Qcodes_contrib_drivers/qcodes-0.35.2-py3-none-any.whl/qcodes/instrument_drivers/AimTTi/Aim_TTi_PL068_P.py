from ._AimTTi_PL_P import AimTTi


class AimTTiPL068P(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL068-P series power supply.
    """

    pass
