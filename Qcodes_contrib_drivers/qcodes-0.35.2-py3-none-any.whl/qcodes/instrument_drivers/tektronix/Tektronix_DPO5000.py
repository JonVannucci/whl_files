from .DPO7200xx import TektronixDPO7000xx


class TektronixDPO5000(TektronixDPO7000xx):
    """
    QCoDeS driver for Tektronix DPO5000 Digital Oscilloscopes
    """
