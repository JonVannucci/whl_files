from .DPO7200xx import TektronixDPO7000xx


class TektronixDPO7000(TektronixDPO7000xx):
    """
    QCoDeS driver for Tektronix DPO7000 Digital Oscilloscopes
    """
