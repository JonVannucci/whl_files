from qcodes.instrument_drivers.Keysight.Keysight_N5183B import N5183B


class N5173B(N5183B):
    pass  # N5173B has the same interface as N5183B
