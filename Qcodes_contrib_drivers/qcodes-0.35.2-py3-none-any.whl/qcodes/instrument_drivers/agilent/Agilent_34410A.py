from ._Agilent_344xxA import _Agilent344xxA


class Agilent34410A(_Agilent344xxA):
    """
    This is the QCoDeS driver for the Agilent 34410A DMM.
    """

    pass
