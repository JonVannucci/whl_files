from .metadatable_base import Metadatable

__all__ = ["Metadatable"]
